
var app = angular.module('myAppValidation', ['ngSanitize']);
app.controller('selfReview', function($scope,$http) {
    
	//hide prodAppID and Dev AppID
	 $scope.showProduction = true;
	 $scope.showDevelopment = true;
	 $scope.reviewResultShow=true; // hide result table
	 $scope.appIdNotFound=true; 
	 $scope.baseRegionSupport=true;  
	 
	 
	 $scope.RegioncountList = [
        { value: 'en-AU', name: 'Australia' },
        { value: 'en-CA', name: 'Canada' },
		{ value: 'en-IN', name: 'India' },
		{ value: 'en-GB', name: 'United Kingdom' },
		{ value: 'en-US', name: 'United States' }
    ];

   // $scope.RegionID = $scope.RegioncountList[0].value;  */
	
	$scope.countList = [
        { value: 'Production', name: 'Production' },
        { value: 'Sandbox', name: 'Development' }
    ];

    //$scope.selectEnviron = $scope.countList[0].value; 
    
	$scope.fnSelectEnvironment = function(value) {
		 $scope.prodAppID = '';
		 $scope.devAppID = '';
		 $scope.validationError ='';
		 $scope.BaseRegionError ='';
		 $scope.appIdNotFound=true;
		 $scope.baseRegionSupport=true; 
		 $scope.showEnvironmentError = false;
		 $scope.showProdAppIdError = false;
		 $scope.showDevAppIdError = false;
		 $scope.showIntuitURLError = false;
		 $scope.showc2qbWidgetError = false;
		 $scope.showRegionIDError = false;
		
		 
        if(value=='Production'){
  			$scope.showProduction = false;
			$scope.showDevelopment = true;
			//$scope.isError = false;
			$scope.devAppID='DUMMY';
        }
		else if(value=='Sandbox')
		{
			 $scope.showProduction = false;
			 $scope.showDevelopment = false;
			 //$scope.isError = false;
		}
		else
		{
		    $scope.showProduction = true;
			$scope.showDevelopment = true;
			//$scope.isError = true;
		}
	}

	$scope.resetFormValues = function() {
		 
		 $scope.selfReviewResult='';
		 $scope.reviewResultShow=true;
		 $scope.selectEnviron = null;
		 $scope.prodAppID = null;
		 $scope.devAppID = null;
		 $scope.intuitURL = null;
		 $scope.c2qbWidget = null; 
		 $scope.RegionID = null;
		 $scope.showProduction = true;
		 $scope.showDevelopment = true;
		 $scope.appIdNotFound=true;
		 $scope.baseRegionSupport=true; 
		 $scope.validationError ='';
		 $scope.BaseRegionError ='';
		 //$scope.resultAppName='';
		 $scope.showEnvironmentError = false;
		 $scope.showProdAppIdError = false;
		 $scope.showDevAppIdError = false;
		 $scope.showIntuitURLError = false;
		 $scope.showc2qbWidgetError = false;
		 $scope.showRegionIDError = false;
        // Todo: Reset field to pristine state, its initial state!
    };


	$scope.selfReviewAppName = function() {
			//	$scope.submitted = true;
			// check to make sure the form is completely valid
			//$scope.selfReview = function () { return $scope.appValidationForm.$invalid; }
		if($scope.appValidationForm.$valid == false){
			//alert('NotValid')
			/*show error message if form is not Valid */
			$scope.validationError ='';
			$scope.BaseRegionError='';
			$scope.appIdNotFound=true;
			$scope.baseRegionSupport=true; 
			$scope.showEnvironmentError = true;
			$scope.showProdAppIdError = true;
			$scope.showDevAppIdError = true;
			$scope.showIntuitURLError = true;
			$scope.showc2qbWidgetError = true;
			$scope.showRegionIDError = true;
		}
		else if ($scope.appValidationForm.$valid) {
			
			/*hide error message if form is Valid */
			$scope.showEnvironmentError = false;
			$scope.showProdAppIdError = false;
			$scope.showDevAppIdError = false;
			$scope.showIntuitURLError = false;
			$scope.showc2qbWidgetError = false;
			$scope.showRegionIDError = false;
			
				var userProdAppID = $scope.prodAppID;
				var userDevAppId = $scope.devAppID;
				var UserAppURL = $scope.intuitURL;
				var userC2qbURL = $scope.c2qbWidget;
				var sandbox = $scope.selectEnviron;
				var passedSandbox=true;
				var passedRegion = $scope.RegionID;
				if(sandbox=="Production"){
					passedSandbox=false;
				}
				var submitJSON = {
						prodAppid: userProdAppID,
						devAppid: userDevAppId,
						appURL: UserAppURL,
						c2qbURL: userC2qbURL,
						   sandbox: passedSandbox,
						   regionID:passedRegion
				       };
				
				
				$scope.showLoader = true; // angular Ajax Loader Starts
			
				$scope.sendButton = true; //disabled button before sending the request 
				$scope.resetButton = true;
				
				/*Reseting the values of results */
				//$scope.resultAppName='';
				$scope.selfReviewResult='';
				$scope.reviewResultShow=true;
				$scope.validationError ='';
				$scope.BaseRegionError ='';
				$scope.appIdNotFound=true;
				$scope.baseRegionSupport=true; 
				
				$http({	method:'POST', 
					   url: '/techreview-service/appreview/v1/app/'+userProdAppID+'?action=validate',
					   headers: {'Content-Type': 'application/json'},
					   data:JSON.stringify(submitJSON),
					   //template:"<h1 ng-if='isRouteLoading'>Loading...</h1>",
							//data : "title=" + $scope.titleName + "&description=" + $scope.sortDescription
							}).
					success(function(data, status) {
						if(status==200){
							
							$scope.reviewResultShow=false; // show result table
							//$scope.showLoader = false; // hide angular Ajax Loader ends
									
							//$scope.resultAppName = 'Review done for the App Name : ' +'"'+data.appName+'"';
							
							var url = "/techreview-service/appreview/events/job/"+data.jobId;
							var eventSource = new EventSource(url);
							eventSource.addEventListener('message-to-client', function(e) {
								var json_obj = JSON.parse(e.data);
									if (json_obj.resultSymbol=='SUCCESS') {
									    var myResult  = '<div class="col-md-9 padding-top-result">'+json_obj.message+'</div><div class="col-md-3"><image src="images/greentick1.png"/></div>';
									    //var myResult  = '<p><span><image src="images/sucessIcon.png"/></span>' +" "+json_obj.message +'</p>';
										$scope.$apply(function () {
											 $scope.selfReviewResult= $scope.selfReviewResult+ myResult;
									        });
									}
									else if (json_obj.resultSymbol=='WARNING') {
									    var myResult  = '<div class="col-md-9 padding-top-result">'+json_obj.message+'</div><div class="col-md-3"><image src="images/warning.png"/></div>';
									    //var myResult  = '<p><span><image src="images/sucessIcon.png"/></span>' +" "+json_obj.message +'</p>';
										$scope.$apply(function () {
											 $scope.selfReviewResult= $scope.selfReviewResult+ myResult;
									        });
									} 
									else {
									     var myResult  = '<div class="col-md-9 padding-top-result">'+json_obj.message+'</div><div class="col-md-3"><image src="images/redcross.png"/></div>';
										// var myResult  = '<p><span><image src="images/failedIcon.png"/></span>' +" "+json_obj.message +'</p>';
										 $scope.$apply(function () {
											 $scope.selfReviewResult= $scope.selfReviewResult+ myResult;
									        });
									}
						        	 if(json_obj.last){
						        		 $scope.$apply(function () {
						        			 $scope.showLoader = false;
						        			 $scope.sendButton = false; // enabling button after success
						        			 $scope.resetButton = false;
						        		 });
						        	 }
					        	}, false);
						}							
					}).
					error(function(data, status) {
						if(status==404) {
							$scope.showLoader = false;  // hide angular Ajax Loader ends
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							$scope.validationError = 'App Id not found';
							$scope.appIdNotFound=false; 
						}
						else if(status==400){
							$scope.showLoader = false; // hide angular Ajax Loader ends
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							$scope.validationError = 'App Id not valid for user';
							$scope.appIdNotFound=false; 
						}
						else if(status==405){
							$scope.showLoader = false; // hide angular Ajax Loader ends
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							$scope.BaseRegionError = data.message;
							$scope.baseRegionSupport=false; 
						}
						else
							{
							$scope.showLoader = false;
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							alert('System Error, Please try again later');	
							}
						
				  }); 

			}
    }

});

function AvoidSpace(event) {
    var k = event ? event.which : window.event.keyCode;
    if (k == 32) return false;
}
