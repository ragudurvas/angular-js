var adminApp = angular.module('adminApplication', []);
adminApp.controller('adminCtrl', function($scope, $http) {
	
	$scope.hideRequirement=true;
	
    $http.get("/techreview-service/appreview/admin/requirement")
    .then(function (response) {$scope.names = response.data;});
    
    $scope.adminStatefunc = function() {
    	
    $scope.json = angular.toJson($scope.names);
    	
    	//alert($scope.json);
    	
   	   $http({	method: "POST", 
   		   		headers: {'Content-Type': 'application/json'}, 
   		   		url: "/techreview-service/appreview/admin/requirement",
   		   		data:$scope.json}).
   		   		success(function(data, status) {			
   		   	}).
			error(function(data, status) {
				console.log("Request failed");
		  }); 
		  
	};
});