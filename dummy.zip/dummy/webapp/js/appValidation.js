
$(document).ready(function(){
	//$('#invalidAppID').hide();
	//var regionValues = {"1" : "US","2" : "UK","3" : "CA","4" : "IN"};
	var regionValues = [
							{ id: "1", name: "Australia"}, 
							{ id: "2", name: "Canada"},
							{ id: "3", name: "India"},
							{ id: "4", name: "United Kingdom"},
							{ id: "5", name: "United States"}	
						];
	
	var $selectRegion = $('#RegionID'); 
	//$selectRegion.find('option').remove();  
	$.each(regionValues,function(i,object) 
	{	
		$selectRegion.append('<option value=' + object.id + '>' + object.name + '</option>');
	});

	$("#testForm").validate({
		onkeyup: false,
		onfocusout: false,
		focusCleanup: true,
		onclick: false,
		rules: {
			selectEnviron: {
                selectEnv: true
            },
			prodAppID: {required:true, noSpace:true},
			devAppID: {required: true},
			intuitURL:{required: true, url: true},
			c2qbWidget:{required: true, url: true},
			RegionID: {
                selectRegion: true
            }
		},
		messages: {
			selectEnviron:{required: "Please Select the Environment"},
			prodAppID: {required: "Please enter the Prod App ID", noSpace:"No Blank Space Allowed"},
			devAppID: {required:"Please enter the Dev App ID"},
			intuitURL: 
			{
	            required: "Please enter Single Sign On Widget URL",
	            url: "Please enter a Valid URL.",
	        },
	        c2qbWidget: {
	            required: "Please enter Connect to QuickBooks Widget URL",
	            url: "Please enter a Valid URL.",
	        },
			RegionID: {required:"Please select the Region"},
		},
		tooltip_options: {
			selectEnviron: {placement:'right'},
			prodAppID: {placement:'right'},
			devAppID: {placement:'right'},
			intuitURL: {placement:'right'},
			c2qbWidget: {placement:'right'},
			RegionID: {placement:'right'}
		}
	 });
	 
	 jQuery.validator.addMethod('selectEnv', function (value) {
        return (value != 'Select');
    }, "Please Select the Environment");
	
	 jQuery.validator.addMethod('selectRegion', function (value) {
        return (value != 'Select');
    }, "Please Select the Region");
	 
	jQuery.validator.addMethod("noSpace", function(value, element) { 
		  return value.indexOf(" ") < 0 && value != ""; 
		}, "No space please and don't leave it empty");

	  
	$("#sendButton").click(function(event) {
		if ($('#testForm').valid()) 
			{
				var userAppID = $('input[name="prodAppID"]').val();
				$("#resultAppName").text('');
				//console.log(formData);
				$.ajax({
						type: 'GET',
						url: '/appvalidationtool/appreview/v1/app/'+userAppID+'?action=validate',
						//data: {applicationID: userAppID},
						contentType: "application/json",
						dataType: "json",
						//setCookies:"iam.userid:=<userid>",
						beforeSend: function() { 
							showAjaxLoader();
							$("#validationError").text('');
							$("#sendButton").prop("disabled", true);
							$("#resetButton").prop("disabled", true);
						},
						success: function (data, xhr) { // 
							hideAjaxLoader();
							$("#sendButton").prop("disabled", false);
							$("#resetButton").prop("disabled", false);
							result = data;
								if(xhr === "success")	{
									$("#resultAppName").text('Review done for the App Name :'+' ' + '" ' +result.appName+' "').css({"color": "green", "font-weight": "bold"});
									
									/* var json = $.parseJSON(data);
									 obj = JSON.parse(text);
									 document.getElementById("demo").innerHTML =
									 obj.employees[1].firstName + " " + obj.employees[1].lastName;*/
									var source = new EventSource("/appvalidationtool/css/appcallBackAPI.html");
									source.onmessage = function(event) {
									   // document.getElementById("selfReviewResult").innerHTML += event.data + "<br>";
									    var json_obj = $.parseJSON(e.data);
 
									var $wrapper = $('<p></p>');

							        if (json_obj.success==true) {
							            var myResult  = $wrapper.append('<span><image src="images/sucessIcon.png"/></span>' + json_obj.requirementId + 'Author: ' + json_obj.success);
							            $('#selfReviewResult').append(myResult);
							        } 
							        else {
							           var myResult = $wrapper.append('<span><image src="images/failedIcon.png"/></span>' + json_obj.requirementId + 'Sucess: ' + json_obj.success);
							           $('#selfReviewResult').append(myResult);
							        }
									}
								}
						},
						error: function (xhr, err) { //400 BAD request received
							console.log('Application id is empty');
							
							//$('#result_user').html('Application id is empty').css('color','red');

							if(xhr.status==404) {
								hideAjaxLoader();
								$("#sendButton").prop("disabled", false);
								$("#resetButton").prop("disabled", false);
								//alert('App Id not found');
								var appIDNotValid = "App Id not found";
								$("#testForm [name='prodAppID']").focus();
								$("#validationError").text(appIDNotValid).css({"color": "red", "font-weight": "bold"});
							}
							else if(xhr.status==400){
								hideAjaxLoader();
								$("#sendButton").prop("disabled", false);
								$("#resetButton").prop("disabled", false);
								//alert('App Id not valid for user');
								var appIDNotValidUser = "App Id not valid for user";
								$("#testForm [name='prodAppID']").focus();
								$("#validationError").text(appIDNotValidUser).css({"color": "red", "font-weight": "bold"});
							}
							else {
								hideAjaxLoader();
								$("#sendButton").prop("disabled", false);
								$("#resetButton").prop("disabled", false);
								alert('System Error, Please try again later ');						
							}
							//$('#invalidAppID').show();
							//console.log("readyState: " + xhr.readyState + "\nstatus: " + xhr.status);
							//console.log("responseText: " + xhr.responseText);
						}
				});
			}
			else
			{
				//$('#loaderBox').hide();
			}
			//event.preventDefault();
		//return false;

	});

	$("#resetButton").click(function() {
		$('#showResult').hide();
	});
	
	$('#selectId').change(function(){fnSelectEnvironment(this)});
	
//Clearing the Resultset form fields
	
	$('#resetButton').click(function(){
		$('#testForm').trigger("reset");
		fnSelectEnvironment(this);
		$('.tooltip').hide();
		$("#validationError").text('');
		$("#resultAppName").text('');
	});
});


function fnSelectEnvironment(currObj) 
{
	var selectEnvironment = $('#selectId').val();
	$('.tooltip').hide();
	$('input[name="prodAppID"]').val('');
	$('input[name="devAppID"]').val('');
	if (selectEnvironment  == "Production") 
	{
		$('#showProduction').show();
		$('#showDevelopment').hide();
		$("#validationError").text('');
	}
	else if(selectEnvironment=='Sandbox'){
		$('#showProduction').show();
		$('#showDevelopment').show();
		$("#validationError").text(''); 
	}
	else 
	{
		$('#showProduction').hide();
		$('#showDevelopment').hide();
		$("#validationError").text('');
	}
	
}
function showAjaxLoader()
{
	var loadingContent = '<span><image src="images/ajax_loader.gif"/></span> <b class="colorGreen">Please wait ... app review is in progress</b>'
	$('#loaderBox').html(loadingContent);
 	// Showing the loader once call triggers.
}
function hideAjaxLoader()
{
	$('#loaderBox').text(''); 
	//$('#loaderBox').hide();
}

