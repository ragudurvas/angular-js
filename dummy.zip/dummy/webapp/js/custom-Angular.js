
var app = angular.module('myAppValidation', []);
app.controller('selfReview', function($scope,$http) {
    
	//hide prodAppID and Dev AppID
	 $scope.showProduction = true;
	 $scope.showDevelopment = true;

	 $scope.RegioncountList = [
        { value: 'Australia', name: 'Australia' },
        { value: 'Canada', name: 'Canada' },
		{ value: 'India', name: 'India' },
		{ value: 'United Kingdom', name: 'United Kingdom' },
		{ value: 'United States', name: 'United States' }
    ];

   // $scope.RegionID = $scope.RegioncountList[0].value;  */
	
	$scope.countList = [
        { value: 'Production', name: 'Production' },
        { value: 'Sandbox', name: 'Development' }
    ];

    //$scope.selectEnviron = $scope.countList[0].value; 
    
	$scope.fnSelectEnvironment = function(value) {
		 $scope.prodAppID = '';
		 $scope.devAppID = '';
		 $scope.validationError ='';
		 $scope.showEnvironmentError = false;
		 $scope.showProdAppIdError = false;
		 $scope.showDevAppIdError = false;
		 $scope.showIntuitURLError = false;
		 $scope.showc2qbWidgetError = false;
		 $scope.showRegionIDError = false;
		
		 
        if(value=='Production'){
  			$scope.showProduction = false;
			$scope.showDevelopment = true;
			//$scope.isError = false;
			$scope.devAppID='DUMMY';
        }
		else if(value=='Sandbox')
		{
			 $scope.showProduction = false;
			 $scope.showDevelopment = false;
			 //$scope.isError = false;
		}
		else
		{
		    $scope.showProduction = true;
			$scope.showDevelopment = true;
			//$scope.isError = true;
		}
	}

	$scope.resetFormValues = function() {
         $scope.prodAppID = '';
		 $scope.devAppID = '';
		 $scope.intuitURL = '';
		 $scope.c2qbWidget = ''; 
		 $scope.showProduction = true;
		 $scope.showDevelopment = true;
		 $scope.validationError =''; 
		 $scope.resultAppName='';
		 $scope.showEnvironmentError = false;
		 $scope.showProdAppIdError = false;
		 $scope.showDevAppIdError = false;
		 $scope.showIntuitURLError = false;
		 $scope.showc2qbWidgetError = false;
		 $scope.showRegionIDError = false;
        // Todo: Reset field to pristine state, its initial state!
    };


	$scope.selfReviewAppName = function() {
			//	$scope.submitted = true;
			// check to make sure the form is completely valid
			//$scope.selfReview = function () { return $scope.appValidationForm.$invalid; }
		if($scope.appValidationForm.$valid == false){
			alert('NotValid')
			/*show error message if form is not Valid */
			$scope.showEnvironmentError = true;
			$scope.showProdAppIdError = true;
			$scope.showDevAppIdError = true;
			$scope.showIntuitURLError = true;
			$scope.showc2qbWidgetError = true;
			$scope.showRegionIDError = true;
		}
		else if ($scope.appValidationForm.$valid) {
			
			/*hide error message if form is Valid */
			$scope.showEnvironmentError = false;
			$scope.showProdAppIdError = false;
			$scope.showDevAppIdError = false;
			$scope.showIntuitURLError = false;
			$scope.showc2qbWidgetError = false;
			$scope.showRegionIDError = false;
			
				var userAppID = document.getElementById("prodAppID").value;
				
				$scope.showLoader = true; // angular Ajax Loader Starts
			
				$scope.sendButton = true; //disabled button before sending the request 
				$scope.resetButton = true;
				
				/*Reseting the values of results */
				$scope.resultAppName='';
				$scope.validationError ='';
				   
				$http({	method:'GET', 
					   url: '/appvalidationtool/appreview/v1/app/'+userAppID+'?action=validate',
					   headers: {'Content-Type': 'application/json'},
					   //template:"<h1 ng-if='isRouteLoading'>Loading...</h1>",
							//data : "title=" + $scope.titleName + "&description=" + $scope.sortDescription
							}).
					success(function(data, status) {
						if(status==200){
							$scope.showLoader = false; // hide angular Ajax Loader ends
							
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							
							$scope.resultAppName = 'Review done for the App Name : ' +'"'+data.appName+'"';
						}							
					}).
					error(function(data, status) {
						
						if(status==404) {
							$scope.showLoader = false;  // hide angular Ajax Loader ends
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							$scope.validationError = 'App Id not found';
						}
						else if(status==400){
							$scope.showLoader = false; // hide angular Ajax Loader ends
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							$scope.validationError = 'App Id not valid for user';
						}
						else
							{
							$scope.showLoader = false;
							$scope.sendButton = false; // enabling button after success
							$scope.resetButton = false;
							alert('System Error, Please try again later ');	
							}
						
				  }); 

			}
    }

});

function AvoidSpace(event) {
    var k = event ? event.which : window.event.keyCode;
    if (k == 32) return false;
}
